<!DOCTYPE html>
<html>
<head>
	<title>Cara Membuat View Pada CodeIgniter | MalasNgoding.com</title>
</head>
<body>
	<h2><?php echo $judul; ?></h2>
	<h3><?php echo $tutorial; ?></h3>
</body>
</html>