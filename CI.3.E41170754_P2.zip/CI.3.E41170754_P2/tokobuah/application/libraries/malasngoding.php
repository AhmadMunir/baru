<?php 

class Malasngoding{

	function nama_saya(){
		echo "Nama saya adalah malasngoding !";
	}

	function nama_kamu($nama){
		echo "Nama kamu adalah ". $nama ." !";
	}
}